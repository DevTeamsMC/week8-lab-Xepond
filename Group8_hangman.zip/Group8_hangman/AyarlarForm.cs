﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Group8_hangman
{
    public partial class AyarlarForm : Form
    {
        public AyarlarForm()
        {
            InitializeComponent();
        }

        public string TimeValue
        {
            get { return txtTime.Text; }
            set { txtTime.Text = value; }
        }

        public int oyunZorlugu
        {
            get
            {
                if (rbEasy.Checked) return 0;
                else if (rbNormal.Checked) return 1;
                else if (rbHard.Checked) return 2;
                else return -1;
            }
            set
            {
                if (value == 0)
                    rbEasy.Checked = true;
                else if (value == 1)
                    rbNormal.Checked = true;
                else if (value == 2)
                    rbHard.Checked = true;
            }
        }

        public int resimSecimi
        {
            get
            {
                if (rbAdam.Checked) return 0;
                else if (rbBalon.Checked) return 1;
                else if (rbDis.Checked) return 2;
                else return -1;
            }
            set
            {
                if (value == 0)
                    rbAdam.Checked = true;
                else if (value == 1)
                    rbBalon.Checked = true;
                else if (value == 2)
                    rbDis.Checked = true;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnApplySettings_Click(object sender, EventArgs e)
        {
            int time;
            int difficulty = -1;
            int image = -1;

            if (int.TryParse(txtTime.Text, out time))
            {
                string timeCsvPath = "time.csv";
                using (StreamWriter sw = new StreamWriter(timeCsvPath))
                {
                    sw.WriteLine(time.ToString());
                }
                MessageBox.Show("Ayarlar başarıyla kaydedildi!", "Başarılı");
            }
            else
            {
                MessageBox.Show("Geçerli bir süre girin", "Hata");
            }

            if (rbEasy.Checked)
                difficulty = 0;
            else if (rbNormal.Checked)
                difficulty = 1;
            else if (rbHard.Checked)
                difficulty = 2;

            string difficultyCsvPath = "difficulty.csv";
            using (StreamWriter sw1 = new StreamWriter(difficultyCsvPath))
            {
                sw1.WriteLine(difficulty.ToString());
            }

            image = resimSecimi;

            string resimCsvPath = "image.csv";
            using (StreamWriter sw2 = new StreamWriter(resimCsvPath))
            {
                sw2.WriteLine(image.ToString());
            }
        }
    }
}
