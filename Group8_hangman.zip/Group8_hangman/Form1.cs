﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group8_hangman
{
    public partial class GirisFormu : Form
    {
        private int oyunSuresi = 60;
        private int oyunZorlugu = 0;
        private int konu = 0;
        private int resim = 0;
        public GirisFormu()
        {
            InitializeComponent();
        }

        public Image LoadEmbeddedImage(string resourceName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                if (stream != null)
                {
                    return Image.FromStream(stream);
                }
                else
                {
                    throw new Exception($"Kaynak bulunamadı: {resourceName}");
                }
            }
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            string csvPath = "time.csv";
            if (File.Exists(csvPath))
            {
                using (StreamReader sr = new StreamReader(csvPath))
                {
                    string line = sr.ReadLine();
                    if (int.TryParse(line, out int sure))
                    {
                        oyunSuresi = sure;
                    }
                }
            }

            string difficultyCsvPath = "difficulty.csv";
            if (File.Exists(difficultyCsvPath))
            {
                using (StreamReader sr1 = new StreamReader(difficultyCsvPath))
                {
                    string line = sr1.ReadLine();
                    if (int.TryParse(line, out int zorluk))
                    {
                        oyunZorlugu = zorluk;
                    }
                }
            }

            string resimCsvPath = "image.csv";
            if (File.Exists(resimCsvPath))
            {
                using (StreamReader sr2 = new StreamReader(resimCsvPath))
                {
                    string line = sr2.ReadLine();
                    if (int.TryParse(line, out int resimSecimi))
                        resim = resimSecimi;
                }
            }

            if (rbCS.Checked)
                konu = 0;
            else if (rbSport.Checked)
                konu = 1;
            else if (rbMusic.Checked)
                konu = 2;

            OyunForm oyunForm = new OyunForm(oyunSuresi, oyunZorlugu, konu, resim); 
            oyunForm.Show();
            this.Hide();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            AyarlarForm ayarForm = new AyarlarForm();
            ayarForm.TimeValue = oyunSuresi.ToString();

            if (ayarForm.ShowDialog() == DialogResult.OK)
            {
                if (int.TryParse(ayarForm.TimeValue, out int secilenSure))
                {
                    oyunSuresi = secilenSure;
                }
            }
        }

        private void GirisFormu_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btnGiris_MouseEnter(object sender, EventArgs e)
        {
            btnGiris.BackColor = Color.Sienna;
        }

        private void btnGiris_MouseLeave(object sender, EventArgs e)
        {
            btnGiris.BackColor = Color.SaddleBrown;
        }

        private void btnSettings_MouseEnter(object sender, EventArgs e)
        {
            btnSettings.BackColor = Color.Sienna;
        }

        private void btnSettings_MouseLeave(object sender, EventArgs e)
        {
            btnSettings.BackColor = Color.SaddleBrown;
        }
    }
}
