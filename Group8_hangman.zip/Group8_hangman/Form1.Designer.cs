﻿namespace Group8_hangman
{
    partial class GirisFormu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGiris = new System.Windows.Forms.Label();
            this.btnGiris = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.rbMusic = new System.Windows.Forms.RadioButton();
            this.rbSport = new System.Windows.Forms.RadioButton();
            this.rbCS = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblGiris
            // 
            this.lblGiris.AutoSize = true;
            this.lblGiris.BackColor = System.Drawing.Color.Transparent;
            this.lblGiris.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGiris.Location = new System.Drawing.Point(246, 33);
            this.lblGiris.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGiris.Name = "lblGiris";
            this.lblGiris.Size = new System.Drawing.Size(181, 40);
            this.lblGiris.TabIndex = 1;
            this.lblGiris.Text = "Hangman";
            // 
            // btnGiris
            // 
            this.btnGiris.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnGiris.FlatAppearance.BorderSize = 0;
            this.btnGiris.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGiris.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGiris.ForeColor = System.Drawing.Color.White;
            this.btnGiris.Location = new System.Drawing.Point(316, 199);
            this.btnGiris.Margin = new System.Windows.Forms.Padding(2);
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Size = new System.Drawing.Size(120, 60);
            this.btnGiris.TabIndex = 2;
            this.btnGiris.Text = "Start";
            this.btnGiris.UseVisualStyleBackColor = false;
            this.btnGiris.Click += new System.EventHandler(this.btnGiris_Click);
            this.btnGiris.MouseEnter += new System.EventHandler(this.btnGiris_MouseEnter);
            this.btnGiris.MouseLeave += new System.EventHandler(this.btnGiris_MouseLeave);
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.SaddleBrown;
            this.btnSettings.FlatAppearance.BorderSize = 0;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.White;
            this.btnSettings.Location = new System.Drawing.Point(491, 200);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(115, 59);
            this.btnSettings.TabIndex = 3;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            this.btnSettings.MouseEnter += new System.EventHandler(this.btnSettings_MouseEnter);
            this.btnSettings.MouseLeave += new System.EventHandler(this.btnSettings_MouseLeave);
            // 
            // rbMusic
            // 
            this.rbMusic.AutoSize = true;
            this.rbMusic.BackColor = System.Drawing.Color.Transparent;
            this.rbMusic.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMusic.Location = new System.Drawing.Point(87, 260);
            this.rbMusic.Name = "rbMusic";
            this.rbMusic.Size = new System.Drawing.Size(68, 24);
            this.rbMusic.TabIndex = 2;
            this.rbMusic.Text = "Music";
            this.rbMusic.UseVisualStyleBackColor = false;
            // 
            // rbSport
            // 
            this.rbSport.AutoSize = true;
            this.rbSport.BackColor = System.Drawing.Color.Transparent;
            this.rbSport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbSport.Location = new System.Drawing.Point(87, 217);
            this.rbSport.Name = "rbSport";
            this.rbSport.Size = new System.Drawing.Size(66, 24);
            this.rbSport.TabIndex = 1;
            this.rbSport.Text = "Sport";
            this.rbSport.UseVisualStyleBackColor = false;
            // 
            // rbCS
            // 
            this.rbCS.AutoSize = true;
            this.rbCS.BackColor = System.Drawing.Color.Transparent;
            this.rbCS.Checked = true;
            this.rbCS.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbCS.Location = new System.Drawing.Point(87, 174);
            this.rbCS.Name = "rbCS";
            this.rbCS.Size = new System.Drawing.Size(158, 24);
            this.rbCS.TabIndex = 0;
            this.rbCS.TabStop = true;
            this.rbCS.Text = "Computer Science";
            this.rbCS.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(87)))), ((int)(((byte)(36)))));
            this.label1.Location = new System.Drawing.Point(118, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "TOPICS";
            // 
            // GirisFormu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Group8_hangman.Properties.Resources.cover;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(684, 411);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rbMusic);
            this.Controls.Add(this.rbSport);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.rbCS);
            this.Controls.Add(this.btnGiris);
            this.Controls.Add(this.lblGiris);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "GirisFormu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GirisFormu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GirisFormu_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblGiris;
        private System.Windows.Forms.Button btnGiris;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.RadioButton rbMusic;
        private System.Windows.Forms.RadioButton rbSport;
        private System.Windows.Forms.RadioButton rbCS;
        private System.Windows.Forms.Label label1;
    }
}

