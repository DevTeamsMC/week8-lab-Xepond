﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Group8_hangman;

namespace Group8_hangman
{
    public partial class OyunForm : Form
    {
        List<string> computerScienceKelimeler = new List<string>
        {
            // Easy
            "python",
            "binary",
            "loop",
            "array",
            "debug",
            "mouse",
            "linux",
            "cache",
            "stack",
            "class",

            // Medium
            "syntax",
            "github",
            "kernel",
            "buffer",
            "object",

            // Hard
            "mutex",
            "quicksort",
            "recursion",
            "virtual",
            "pipeline"
        };

        List<string> sportsKelimeler = new List<string>
        {
            // Easy
            "soccer",
            "tennis",
            "boxing",
            "golf",
            "chess",
            "swimming",
            "skiing",
            "cricket",
            "rugby",
            "karate",

            // Medium
            "marathon",
            "fencing",
            "curling",
            "vault",
            "hurdle",

            // Hard
            "decathlon",
            "freestyle",
            "pentathlon",
            "bobsleigh",
            "handball",
            "okinawa"
        };

        List<string> musicKelimeler = new List<string>
        {
            // Easy
            "guitar",
            "piano",
            "beat",
            "scale",
            "choir",
            "note",
            "pop",
            "drums",
            "rap",
            "hymn",

            // Medium
            "octave",
            "violin",
            "tenor",
            "tempo",
            "chorus",

            // Hard
            "soprano",
            "sitar",
            "libretto",
            "atonal",
            "synth"
        };

        Dictionary<string, string> computerScienceIpuclari = new Dictionary<string, string>
        {
            // Easy
            { "python", "A popular programming language named after a comedy group." },
            { "binary", "A number system with only 0s and 1s." },
            { "loop", "A programming structure that repeats code." },
            { "array", "A data structure that stores elements in a list." },
            { "debug", "The process of finding and fixing errors in code." },
            { "mouse", "A common computer input device." },
            { "linux", "An open-source operating system." },
            { "cache", "Stores temporary data for faster access." },
            { "stack", "A data structure with LIFO access." },
            { "class", "Blueprint for creating objects in OOP." },

            // Medium
            { "syntax", "Set of rules that defines the combinations of symbols in a language." },
            { "github", "Popular platform for hosting and sharing code." },
            { "kernel", "The core part of an operating system." },
            { "buffer", "Temporary memory storage during processing or I/O." },
            { "object", "Instance of a class in object-oriented programming." },

            // Hard
            { "mutex", "Used to prevent concurrent access in multithreading." },
            { "quicksort", "A fast, divide-and-conquer sorting algorithm." },
            { "recursion", "Function that calls itself in programming." },
            { "virtual", "A method that can be overridden in OOP." },
            { "pipeline", "Instruction execution method in CPUs for performance." }

        };

        Dictionary<string, string> sportsIpuclari = new Dictionary<string, string>
        {
            // Easy
            { "soccer", "The most popular sport in the world." },
            { "tennis", "Game played with a racket and ball on a court." },
            { "boxing", "Sport where two opponents punch in a ring." },
            { "golf", "Sport where players aim for a hole with fewest strokes." },
            { "chess", "A strategic board game played by two people." },
            { "swimming", "Sport where you move through water." },
            { "skiing", "Winter sport done on snow with long narrow boards." },
            { "cricket", "Bat-and-ball game popular in England and India." },
            { "rugby", "Tackle sport with an oval ball, popular in the UK." },
            { "karate", "Japanese martial art using punches and kicks." },

            // Medium
            { "marathon", "Race with a distance of 42.195 km." },
            { "fencing", "Sword fighting sport with foils and masks." },
            { "curling", "Winter sport played with stones on ice." },
            { "vault", "Gymnastics event involving a springboard and table." },
            { "hurdle", "Race that includes jumping over barriers." },

            // Hard
            { "decathlon", "Ten-event athletic competition." },
            { "freestyle", "Swimming stroke with the fastest technique." },
            { "pentathlon", "Modern sport including five different events." },
            { "bobsleigh", "Winter sliding sport on an ice track." },
            { "handball", "Sport where players use their hands to pass a ball into a goal." },
            { "okinawa", "The island that karate was originated." }
        };

        Dictionary<string, string> musicIpuclari = new Dictionary<string, string>
        {
            // Easy
            { "guitar", "A six-string instrument." },
            { "piano", "Instrument with black and white keys." },
            { "beat", "Basic unit of time in music." },
            { "scale", "Series of notes in ascending or descending order." },
            { "choir", "Group of singers." },
            { "note", "Basic symbol in sheet music." },
            { "pop", "Popular genre of modern music." },
            { "drums", "Percussion instrument often used in bands." },
            { "rap", "Rhythmic and rhyming speech genre." },
            { "hymn", "Religious song or praise tune." },

            // Medium
            { "octave", "Interval between one musical pitch and another with double its frequency." },
            { "violin", "A string instrument held under the chin." },
            { "tenor", "A high male singing voice." },
            { "tempo", "The speed at which a piece of music is played." },
            { "chorus", "Repeated section of a song, often catchy." },

            // Hard
            { "soprano", "The highest vocal range for females." },
            { "sitar", "Traditional Indian string instrument." },
            { "libretto", "Text of an opera or other vocal work." },
            { "atonal", "Music lacking a clear key or tonal center." },
            { "synth", "Electronic instrument generating audio signals." }

        };

        Timer oyunZamani = new Timer();
        Timer renkZamanlayici = new Timer();
        Color varsayilanRenk;
        public int kalanSure { get; set; } = 60;
        string seciliKelime;
        string gosterilenKelime;
        int yanlisTahminler = 0;
        int puan = 90;
        List<char> yanlisHarfler = new List<char>();

        public int oyunZorlugu;
        public int oyunKonusu;
        public int oyunResim;

        public OyunForm(int sure = 60, int zorluk = 0, int konu = 0, int resim = 0)
        {
            InitializeComponent();
            txtTahmin.KeyDown += txtTahmin_KeyDown;
            this.FormClosing += OyunForm_FormClosing;
            kalanSure = sure;
            oyunZorlugu = zorluk;
            oyunKonusu = konu;
            oyunResim = resim;
            StartGame();
        }

        private Image GetHangmanImage(int index)
        {
            if (oyunResim == 0) // man
            {
                string resourceName = $"Group8_hangman.man-{index.ToString("D2")}.jpg";
                var assembly = Assembly.GetExecutingAssembly();
                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    return Image.FromStream(stream);
                }
            }
            else if (oyunResim == 1) // baloon
            {
                string resourceName1 = $"Group8_hangman.balon-{index.ToString("D2")}.jpg";
                var assembly1 = Assembly.GetExecutingAssembly();
                using (Stream stream1 = assembly1.GetManifestResourceStream(resourceName1))
                {
                    return Image.FromStream(stream1);
                }
            }
            else if (oyunResim == 2) // teeth
            {
                string resourceName2 = $"Group8_hangman.dis-{index.ToString("D2")}.jpg";
                var assembly2 = Assembly.GetExecutingAssembly();
                using (Stream stream2 = assembly2.GetManifestResourceStream(resourceName2))
                {
                    return Image.FromStream(stream2);
                }
            }
            else // default man
            {
                string resourceName = $"Group8_hangman.man-{index.ToString("D2")}.jpg";
                var assembly = Assembly.GetExecutingAssembly();
                using (Stream stream = assembly.GetManifestResourceStream(resourceName))
                {
                    return Image.FromStream(stream);
                }
            }
            
        }


        void StartGame()
        {
            lblAyarlariniz.Text = $"Time: {kalanSure} seconds";

            if (oyunKonusu == 0)
                lblAyarlariniz.Text += " - Topic: Computer Science";
            else if (oyunKonusu == 1)
                lblAyarlariniz.Text += " - Topic: Sports";
            else
                lblAyarlariniz.Text += " - Topic: Music";

            if (oyunZorlugu == 0)
                lblAyarlariniz.Text += " - Level: Easy";
            else if (oyunZorlugu == 1)
                lblAyarlariniz.Text += " - Level: Normal";
            else
                lblAyarlariniz.Text += " - Level: Hard";


            Random rnd = new Random();

            if (oyunKonusu == 0)
            {
                if (oyunZorlugu == 0)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 1)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(11, 16)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 2)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(16, 21)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
            }
            else if (oyunKonusu == 1)
            {
                if (oyunZorlugu == 0)
                {
                    seciliKelime = sportsKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = sportsIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 1)
                {
                    seciliKelime = sportsKelimeler[rnd.Next(11, 16)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = sportsIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 2)
                {
                    seciliKelime = sportsKelimeler[rnd.Next(16, 22)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = sportsIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else
                {
                    seciliKelime = sportsKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = sportsIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
            }
            else if (oyunKonusu == 2)
            {
                if (oyunZorlugu == 0)
                {
                    seciliKelime = musicKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = musicIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 1)
                {
                    seciliKelime = musicKelimeler[rnd.Next(11, 16)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = musicIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 2)
                {
                    seciliKelime = musicKelimeler[rnd.Next(16, 21)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = musicIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else
                {
                    seciliKelime = musicKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = musicIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
            }
            else
            {
                MessageBox.Show("There is a problem with configuration. Computer Science topic on easy mode in 60 will be played.", "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (oyunZorlugu == 0)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(1, 11)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
                else if (oyunZorlugu == 1)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(11, 16)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }  
                else if (oyunZorlugu == 2)
                {
                    seciliKelime = computerScienceKelimeler[rnd.Next(16, 21)];
                    gosterilenKelime = new string('_', seciliKelime.Length);
                    lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());
                    lblYardim.Text = computerScienceIpuclari[seciliKelime];
                    lblKelimeUzunlugu.Text = $"Word Length: {seciliKelime.Length}";
                }
            }

            lblPuan.Text = "Score: 90";
            pbAdam.Image = GetHangmanImage(1);

            oyunZamani.Interval = 1000;
            oyunZamani.Tick += OyunZamani_Tick;
            oyunZamani.Start();

            varsayilanRenk = this.BackColor;
            renkZamanlayici.Interval = 1000;
            renkZamanlayici.Tick += (s, e) =>
            {
                this.BackColor = varsayilanRenk;
                renkZamanlayici.Stop();
            };
            txtTahmin.Focus();
        }

        private void OyunZamani_Tick(object sender, EventArgs e)
        {
            kalanSure--;
            lblPuan.Text = $"Score: {puan}";

            lblSure.Text = $"Time Remaining: {kalanSure} seconds";

            if (kalanSure <= 0)
            {
                oyunZamani.Stop();
                MessageBox.Show("Time is up! You are directed to the login screen.", "Time is up");

                GirisFormu girisForm = new GirisFormu();
                girisForm.Show();
                this.Close();
            }
        }

        void CheckGameState()
        {
            if (!gosterilenKelime.Contains('_'))
            {
                renkZamanlayici.Stop();
                this.BackColor = Color.Green;
                DisableGame();
                MessageBox.Show("Congratulations, you guessed the word correctly!");

            }
            else if (yanlisTahminler >= 9)
            {
                renkZamanlayici.Stop();
                BackColor = Color.Red;
                DisableGame();
                var result = MessageBox.Show($"You couldn't guessed the word correctly. The word was: {seciliKelime}", "Game is Over", MessageBoxButtons.OK, MessageBoxIcon.Question);
                if (result == DialogResult.OK)
                    this.Close();
            }
        }

        void DisableGame()
        {
            txtTahmin.Enabled = false;
            btnTahmin.Enabled = false;
            oyunZamani.Stop();
        }

        private void btnTahmin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTahmin.Text)) return;

            char tahmin = char.ToLower(txtTahmin.Text[0]);
            txtTahmin.Clear();

            if (seciliKelime.Contains(tahmin))
            {
                char[] newDisplay = gosterilenKelime.ToCharArray();
                for (int i = 0; i < seciliKelime.Length; i++)
                {
                    if (seciliKelime[i] == tahmin)
                        newDisplay[i] = tahmin;
                }
                gosterilenKelime = new string(newDisplay);
                lblKelime.Text = string.Join(" ", gosterilenKelime.ToCharArray());

                this.BackColor = Color.Green;
                renkZamanlayici.Start();
            }
            else if (!yanlisHarfler.Contains(tahmin))
            {
                yanlisHarfler.Add(tahmin);
                lblYanlisTahminler.Text = "Wrong Letters: " + string.Join(" ", yanlisHarfler);
                yanlisTahminler++;
                puan -= 10;

                if (yanlisTahminler <= 9)
                    pbAdam.Image = GetHangmanImage(yanlisTahminler + 1);

                this.BackColor = Color.Red;
                renkZamanlayici.Start();
            }
            txtTahmin.Focus();
            CheckGameState();
        }
        private void OyunForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                oyunZamani.Stop();
                GirisFormu girisForm = new GirisFormu();
                girisForm.Show();
            }
        }

        private void btnBitir_Click(object sender, EventArgs e)
        {
            oyunZamani.Stop();

            var result = MessageBox.Show("Really want to exit the game?", "Exit the Game", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            else
            {
                oyunZamani.Start();
            }
        }

        private void txtTahmin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnTahmin.PerformClick();
                e.SuppressKeyPress = true;
            }
        }
    }
}
