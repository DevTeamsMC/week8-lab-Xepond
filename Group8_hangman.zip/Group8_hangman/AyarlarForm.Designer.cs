﻿namespace Group8_hangman
{
    partial class AyarlarForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTime = new System.Windows.Forms.Label();
            this.txtTime = new System.Windows.Forms.TextBox();
            this.btnApplySettings = new System.Windows.Forms.Button();
            this.gboxTime = new System.Windows.Forms.GroupBox();
            this.rbEasy = new System.Windows.Forms.RadioButton();
            this.rbNormal = new System.Windows.Forms.RadioButton();
            this.rbHard = new System.Windows.Forms.RadioButton();
            this.gboxLevel = new System.Windows.Forms.GroupBox();
            this.rbAdam = new System.Windows.Forms.RadioButton();
            this.rbBalon = new System.Windows.Forms.RadioButton();
            this.rbDis = new System.Windows.Forms.RadioButton();
            this.gboxImage = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gboxTime.SuspendLayout();
            this.gboxLevel.SuspendLayout();
            this.gboxImage.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.Color.Transparent;
            this.lblTime.ForeColor = System.Drawing.Color.Black;
            this.lblTime.Location = new System.Drawing.Point(15, 30);
            this.lblTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(114, 16);
            this.lblTime.TabIndex = 0;
            this.lblTime.Text = "Time (in seconds)";
            // 
            // txtTime
            // 
            this.txtTime.BackColor = System.Drawing.Color.White;
            this.txtTime.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTime.Location = new System.Drawing.Point(19, 64);
            this.txtTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(93, 31);
            this.txtTime.TabIndex = 1;
            this.txtTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // btnApplySettings
            // 
            this.btnApplySettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApplySettings.Location = new System.Drawing.Point(380, 377);
            this.btnApplySettings.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnApplySettings.Name = "btnApplySettings";
            this.btnApplySettings.Size = new System.Drawing.Size(189, 58);
            this.btnApplySettings.TabIndex = 2;
            this.btnApplySettings.Text = "Apply Settings";
            this.btnApplySettings.UseVisualStyleBackColor = true;
            this.btnApplySettings.Click += new System.EventHandler(this.btnApplySettings_Click);
            // 
            // gboxTime
            // 
            this.gboxTime.BackColor = System.Drawing.SystemColors.Control;
            this.gboxTime.Controls.Add(this.txtTime);
            this.gboxTime.Controls.Add(this.lblTime);
            this.gboxTime.ForeColor = System.Drawing.Color.Black;
            this.gboxTime.Location = new System.Drawing.Point(91, 169);
            this.gboxTime.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gboxTime.Name = "gboxTime";
            this.gboxTime.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gboxTime.Size = new System.Drawing.Size(187, 114);
            this.gboxTime.TabIndex = 3;
            this.gboxTime.TabStop = false;
            this.gboxTime.Text = "Time";
            // 
            // rbEasy
            // 
            this.rbEasy.AutoSize = true;
            this.rbEasy.Checked = true;
            this.rbEasy.ForeColor = System.Drawing.Color.Black;
            this.rbEasy.Location = new System.Drawing.Point(29, 34);
            this.rbEasy.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbEasy.Name = "rbEasy";
            this.rbEasy.Size = new System.Drawing.Size(59, 20);
            this.rbEasy.TabIndex = 4;
            this.rbEasy.TabStop = true;
            this.rbEasy.Text = "Easy";
            this.rbEasy.UseVisualStyleBackColor = true;
            // 
            // rbNormal
            // 
            this.rbNormal.AutoSize = true;
            this.rbNormal.ForeColor = System.Drawing.Color.Black;
            this.rbNormal.Location = new System.Drawing.Point(29, 78);
            this.rbNormal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbNormal.Name = "rbNormal";
            this.rbNormal.Size = new System.Drawing.Size(72, 20);
            this.rbNormal.TabIndex = 5;
            this.rbNormal.Text = "Normal";
            this.rbNormal.UseVisualStyleBackColor = true;
            // 
            // rbHard
            // 
            this.rbHard.AutoSize = true;
            this.rbHard.ForeColor = System.Drawing.Color.Black;
            this.rbHard.Location = new System.Drawing.Point(29, 121);
            this.rbHard.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbHard.Name = "rbHard";
            this.rbHard.Size = new System.Drawing.Size(58, 20);
            this.rbHard.TabIndex = 6;
            this.rbHard.Text = "Hard";
            this.rbHard.UseVisualStyleBackColor = true;
            // 
            // gboxLevel
            // 
            this.gboxLevel.BackColor = System.Drawing.Color.Transparent;
            this.gboxLevel.Controls.Add(this.rbHard);
            this.gboxLevel.Controls.Add(this.rbNormal);
            this.gboxLevel.Controls.Add(this.rbEasy);
            this.gboxLevel.ForeColor = System.Drawing.Color.Black;
            this.gboxLevel.Location = new System.Drawing.Point(380, 122);
            this.gboxLevel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gboxLevel.Name = "gboxLevel";
            this.gboxLevel.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gboxLevel.Size = new System.Drawing.Size(196, 176);
            this.gboxLevel.TabIndex = 7;
            this.gboxLevel.TabStop = false;
            this.gboxLevel.Text = "Level";
            // 
            // rbAdam
            // 
            this.rbAdam.AutoSize = true;
            this.rbAdam.Checked = true;
            this.rbAdam.ForeColor = System.Drawing.Color.Black;
            this.rbAdam.Location = new System.Drawing.Point(28, 34);
            this.rbAdam.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbAdam.Name = "rbAdam";
            this.rbAdam.Size = new System.Drawing.Size(54, 20);
            this.rbAdam.TabIndex = 8;
            this.rbAdam.TabStop = true;
            this.rbAdam.Text = "Man";
            this.rbAdam.UseVisualStyleBackColor = true;
            // 
            // rbBalon
            // 
            this.rbBalon.AutoSize = true;
            this.rbBalon.ForeColor = System.Drawing.Color.Black;
            this.rbBalon.Location = new System.Drawing.Point(28, 76);
            this.rbBalon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbBalon.Name = "rbBalon";
            this.rbBalon.Size = new System.Drawing.Size(78, 20);
            this.rbBalon.TabIndex = 9;
            this.rbBalon.Text = "Baloons";
            this.rbBalon.UseVisualStyleBackColor = true;
            // 
            // rbDis
            // 
            this.rbDis.AutoSize = true;
            this.rbDis.ForeColor = System.Drawing.Color.Black;
            this.rbDis.Location = new System.Drawing.Point(28, 119);
            this.rbDis.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rbDis.Name = "rbDis";
            this.rbDis.Size = new System.Drawing.Size(63, 20);
            this.rbDis.TabIndex = 10;
            this.rbDis.Text = "Teeth";
            this.rbDis.UseVisualStyleBackColor = true;
            // 
            // gboxImage
            // 
            this.gboxImage.BackColor = System.Drawing.Color.Transparent;
            this.gboxImage.Controls.Add(this.rbDis);
            this.gboxImage.Controls.Add(this.rbBalon);
            this.gboxImage.Controls.Add(this.rbAdam);
            this.gboxImage.ForeColor = System.Drawing.Color.Black;
            this.gboxImage.Location = new System.Drawing.Point(661, 122);
            this.gboxImage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gboxImage.Name = "gboxImage";
            this.gboxImage.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gboxImage.Size = new System.Drawing.Size(189, 175);
            this.gboxImage.TabIndex = 11;
            this.gboxImage.TabStop = false;
            this.gboxImage.Text = "Image";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(357, 34);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 46);
            this.label1.TabIndex = 12;
            this.label1.Text = "SETTINGS";
            // 
            // AyarlarForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 506);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gboxImage);
            this.Controls.Add(this.gboxLevel);
            this.Controls.Add(this.gboxTime);
            this.Controls.Add(this.btnApplySettings);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "AyarlarForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AyarlarForm";
            this.gboxTime.ResumeLayout(false);
            this.gboxTime.PerformLayout();
            this.gboxLevel.ResumeLayout(false);
            this.gboxLevel.PerformLayout();
            this.gboxImage.ResumeLayout(false);
            this.gboxImage.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox txtTime;
        private System.Windows.Forms.Button btnApplySettings;
        private System.Windows.Forms.GroupBox gboxTime;
        private System.Windows.Forms.RadioButton rbEasy;
        private System.Windows.Forms.RadioButton rbNormal;
        private System.Windows.Forms.RadioButton rbHard;
        private System.Windows.Forms.GroupBox gboxLevel;
        private System.Windows.Forms.RadioButton rbAdam;
        private System.Windows.Forms.RadioButton rbBalon;
        private System.Windows.Forms.RadioButton rbDis;
        private System.Windows.Forms.GroupBox gboxImage;
        private System.Windows.Forms.Label label1;
    }
}