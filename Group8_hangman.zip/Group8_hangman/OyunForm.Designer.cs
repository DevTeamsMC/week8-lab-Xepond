﻿namespace Group8_hangman
{
    partial class OyunForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOyun = new System.Windows.Forms.Label();
            this.txtTahmin = new System.Windows.Forms.TextBox();
            this.btnTahmin = new System.Windows.Forms.Button();
            this.lblKelime = new System.Windows.Forms.Label();
            this.lblYardim = new System.Windows.Forms.Label();
            this.lblYanlisTahminler = new System.Windows.Forms.Label();
            this.lblPuan = new System.Windows.Forms.Label();
            this.btnBitir = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblSure = new System.Windows.Forms.Label();
            this.lblKelimeUzunlugu = new System.Windows.Forms.Label();
            this.pbAdam = new System.Windows.Forms.PictureBox();
            this.lblAyarlariniz = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdam)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOyun
            // 
            this.lblOyun.AutoSize = true;
            this.lblOyun.BackColor = System.Drawing.Color.Transparent;
            this.lblOyun.Font = new System.Drawing.Font("Arial Rounded MT Bold", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOyun.ForeColor = System.Drawing.Color.Black;
            this.lblOyun.Location = new System.Drawing.Point(91, 30);
            this.lblOyun.Name = "lblOyun";
            this.lblOyun.Size = new System.Drawing.Size(257, 51);
            this.lblOyun.TabIndex = 0;
            this.lblOyun.Text = "HANGMAN";
            // 
            // txtTahmin
            // 
            this.txtTahmin.BackColor = System.Drawing.Color.White;
            this.txtTahmin.Location = new System.Drawing.Point(27, 389);
            this.txtTahmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtTahmin.Name = "txtTahmin";
            this.txtTahmin.Size = new System.Drawing.Size(172, 22);
            this.txtTahmin.TabIndex = 2;
            // 
            // btnTahmin
            // 
            this.btnTahmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTahmin.Location = new System.Drawing.Point(260, 359);
            this.btnTahmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnTahmin.Name = "btnTahmin";
            this.btnTahmin.Size = new System.Drawing.Size(89, 62);
            this.btnTahmin.TabIndex = 3;
            this.btnTahmin.Text = "Guess";
            this.btnTahmin.UseVisualStyleBackColor = true;
            this.btnTahmin.Click += new System.EventHandler(this.btnTahmin_Click);
            // 
            // lblKelime
            // 
            this.lblKelime.AutoSize = true;
            this.lblKelime.BackColor = System.Drawing.Color.Transparent;
            this.lblKelime.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKelime.ForeColor = System.Drawing.Color.Black;
            this.lblKelime.Location = new System.Drawing.Point(21, 126);
            this.lblKelime.Name = "lblKelime";
            this.lblKelime.Size = new System.Drawing.Size(88, 38);
            this.lblKelime.TabIndex = 4;
            this.lblKelime.Text = "word";
            // 
            // lblYardim
            // 
            this.lblYardim.BackColor = System.Drawing.Color.Transparent;
            this.lblYardim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYardim.ForeColor = System.Drawing.Color.Black;
            this.lblYardim.Location = new System.Drawing.Point(241, 194);
            this.lblYardim.MaximumSize = new System.Drawing.Size(267, 62);
            this.lblYardim.Name = "lblYardim";
            this.lblYardim.Size = new System.Drawing.Size(267, 62);
            this.lblYardim.TabIndex = 5;
            this.lblYardim.Text = "Hint";
            this.lblYardim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblYanlisTahminler
            // 
            this.lblYanlisTahminler.AutoSize = true;
            this.lblYanlisTahminler.BackColor = System.Drawing.Color.Transparent;
            this.lblYanlisTahminler.ForeColor = System.Drawing.Color.Black;
            this.lblYanlisTahminler.Location = new System.Drawing.Point(24, 303);
            this.lblYanlisTahminler.Name = "lblYanlisTahminler";
            this.lblYanlisTahminler.Size = new System.Drawing.Size(93, 16);
            this.lblYanlisTahminler.TabIndex = 6;
            this.lblYanlisTahminler.Text = "Wrong Letters:";
            // 
            // lblPuan
            // 
            this.lblPuan.AutoSize = true;
            this.lblPuan.BackColor = System.Drawing.Color.Transparent;
            this.lblPuan.ForeColor = System.Drawing.Color.Black;
            this.lblPuan.Location = new System.Drawing.Point(25, 331);
            this.lblPuan.Name = "lblPuan";
            this.lblPuan.Size = new System.Drawing.Size(49, 16);
            this.lblPuan.TabIndex = 7;
            this.lblPuan.Text = "Score: ";
            // 
            // btnBitir
            // 
            this.btnBitir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBitir.Location = new System.Drawing.Point(403, 359);
            this.btnBitir.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBitir.Name = "btnBitir";
            this.btnBitir.Size = new System.Drawing.Size(89, 62);
            this.btnBitir.TabIndex = 8;
            this.btnBitir.Text = "Exit";
            this.btnBitir.UseVisualStyleBackColor = true;
            this.btnBitir.Click += new System.EventHandler(this.btnBitir_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(25, 369);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Make a guess";
            // 
            // lblSure
            // 
            this.lblSure.AutoSize = true;
            this.lblSure.BackColor = System.Drawing.Color.Transparent;
            this.lblSure.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSure.ForeColor = System.Drawing.Color.Red;
            this.lblSure.Location = new System.Drawing.Point(540, 75);
            this.lblSure.Name = "lblSure";
            this.lblSure.Size = new System.Drawing.Size(62, 29);
            this.lblSure.TabIndex = 10;
            this.lblSure.Text = "time";
            // 
            // lblKelimeUzunlugu
            // 
            this.lblKelimeUzunlugu.AutoSize = true;
            this.lblKelimeUzunlugu.BackColor = System.Drawing.Color.Transparent;
            this.lblKelimeUzunlugu.ForeColor = System.Drawing.Color.Black;
            this.lblKelimeUzunlugu.Location = new System.Drawing.Point(25, 273);
            this.lblKelimeUzunlugu.Name = "lblKelimeUzunlugu";
            this.lblKelimeUzunlugu.Size = new System.Drawing.Size(86, 16);
            this.lblKelimeUzunlugu.TabIndex = 11;
            this.lblKelimeUzunlugu.Text = "Word Length:";
            // 
            // pbAdam
            // 
            this.pbAdam.Location = new System.Drawing.Point(537, 107);
            this.pbAdam.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pbAdam.Name = "pbAdam";
            this.pbAdam.Size = new System.Drawing.Size(345, 314);
            this.pbAdam.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAdam.TabIndex = 1;
            this.pbAdam.TabStop = false;
            // 
            // lblAyarlariniz
            // 
            this.lblAyarlariniz.AutoSize = true;
            this.lblAyarlariniz.BackColor = System.Drawing.Color.Transparent;
            this.lblAyarlariniz.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAyarlariniz.ForeColor = System.Drawing.Color.Red;
            this.lblAyarlariniz.Location = new System.Drawing.Point(16, 475);
            this.lblAyarlariniz.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAyarlariniz.Name = "lblAyarlariniz";
            this.lblAyarlariniz.Size = new System.Drawing.Size(109, 20);
            this.lblAyarlariniz.TabIndex = 12;
            this.lblAyarlariniz.Text = "Your Settings";
            // 
            // OyunForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(912, 506);
            this.Controls.Add(this.lblAyarlariniz);
            this.Controls.Add(this.lblKelimeUzunlugu);
            this.Controls.Add(this.lblSure);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnBitir);
            this.Controls.Add(this.lblPuan);
            this.Controls.Add(this.lblYanlisTahminler);
            this.Controls.Add(this.lblYardim);
            this.Controls.Add(this.lblKelime);
            this.Controls.Add(this.btnTahmin);
            this.Controls.Add(this.txtTahmin);
            this.Controls.Add(this.pbAdam);
            this.Controls.Add(this.lblOyun);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "OyunForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "OyunForm";
            ((System.ComponentModel.ISupportInitialize)(this.pbAdam)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOyun;
        private System.Windows.Forms.PictureBox pbAdam;
        private System.Windows.Forms.TextBox txtTahmin;
        private System.Windows.Forms.Button btnTahmin;
        private System.Windows.Forms.Label lblKelime;
        private System.Windows.Forms.Label lblYardim;
        private System.Windows.Forms.Label lblYanlisTahminler;
        private System.Windows.Forms.Label lblPuan;
        private System.Windows.Forms.Button btnBitir;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblSure;
        private System.Windows.Forms.Label lblKelimeUzunlugu;
        private System.Windows.Forms.Label lblAyarlariniz;
    }
}